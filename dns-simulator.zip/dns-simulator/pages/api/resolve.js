/**
 * pages/api/resolve.js
 * Simulated DNS resolver with in-memory cache and TTL.
 *
 * Note: This is a demo. On Vercel serverless functions, memory may not persist across cold starts.
 * For persistent cache use Redis / external DB.
 */

let CACHE = {}; // key -> { record, expiresAt, type }

const AUTHORITATIVE = {
  "google.com": { A: ["142.250.190.4"], AAAA: ["2607:f8b0:..."], MX: ["alt1.aspmx.l.google.com"], CNAME: [] },
  "yahoo.com": { A: ["98.137.11.163"], AAAA: [], MX: ["mta.mail.yahoo.com"], CNAME: [] },
  "example.com": { A: ["93.184.216.34"], AAAA: [], MX: ["mx.example.com"], CNAME: [] },
  "vit.ac.in": { A: ["13.90.12.31"], AAAA: [], MX: ["mail.vit.ac.in"], CNAME: [] }
};

function nowSecs(){ return Math.floor(Date.now()/1000); }

export default function handler(req, res){
  if (req.method !== 'POST') return res.status(405).end();

  const { domain = 'www.example.com', query_type = 'A', ttl = 60 } = req.body || {};
  const steps = [];
  const start = Date.now();
  let ip = null;
  let cacheHit = false;

  steps.push(`Start resolution for ${domain} [${query_type}]`);
  steps.push("Step 1: Check local DNS cache...");

  // Check cache
  const cached = CACHE[domain];
  if (cached && cached.expiresAt > nowSecs() && (cached.type === query_type || cached.type === 'ANY')) {
    ip = cached.record;
    cacheHit = true;
    steps.push(`Cache HIT: returning cached record (expires in ${cached.expiresAt - nowSecs()}s).`);
  } else {
    if (cached && cached.expiresAt <= nowSecs()) {
      steps.push("Cache entry expired. Removing from cache.");
      delete CACHE[domain];
    } else {
      steps.push("Cache MISS. Querying recursive resolver...");
    }

    // Simulate recursive resolver steps
    steps.push("Recursive resolver: querying Root name server...");
    steps.push("Root: referral to TLD name server...");
    const parts = domain.split('.').filter(Boolean);
    const base = parts.slice(-2).join('.');
    steps.push(`TLD server: referral to authoritative server for ${base}...`);

    // Authoritative lookup
    const auth = AUTHORITATIVE[base];
    if (auth && auth[query_type] && auth[query_type].length > 0) {
      ip = auth[query_type];
      steps.push(`Authoritative server: found record ${JSON.stringify(ip)} for ${base}.`);
      // store in cache with TTL
      const expiresAt = nowSecs() + Number(ttl || 60);
      CACHE[domain] = { record: ip, expiresAt, type: query_type };
      steps.push(`Stored in local cache with TTL=${ttl}s.`);
    } else if (auth && query_type !== 'A' && auth['A'] && auth['A'].length>0) {
      // fallback to A if available
      ip = auth['A'];
      steps.push(`Authoritative server has 'A' record; returning A record as fallback.`);
      const expiresAt = nowSecs() + Number(ttl || 60);
      CACHE[domain] = { record: ip, expiresAt, type: 'A' };
    } else {
      ip = "Resolution Failed";
      steps.push(`Authoritative server: no ${query_type} record found for ${base}.`);
    }
  }

  const totalTime = ((Date.now() - start)/1000).toFixed(3);

  return res.status(200).json({
    domain, query_type, ip, cache_hit: cacheHit, time: totalTime, steps
  });
}
