import { useState } from 'react';
import Head from 'next/head';
import '../styles/globals.css';

export default function Home(){
  const [domain, setDomain] = useState('www.example.com');
  const [qtype, setQtype] = useState('A');
  const [ttl, setTtl] = useState(60);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  async function resolveDNS(){
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/resolve', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ domain, query_type: qtype, ttl: Number(ttl) })
      });
      const data = await res.json();
      setResult(data);
    } catch (e) {
      setResult({ error: e.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <Head>
        <title>DNS Simulator</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div className="container">
        <h1 style={{fontSize:28, color:'#7dd3fc'}}>🌍 DNS Resolution Simulator</h1>

        <div style={{display:'flex', gap:10, marginTop:16}}>
          <input style={{flex:1, padding:10, borderRadius:8, border:'1px solid #2b3648'}} value={domain} onChange={e=>setDomain(e.target.value)} />
          <select value={qtype} onChange={e=>setQtype(e.target.value)} style={{padding:10, borderRadius:8}}>
            <option>A</option>
            <option>AAAA</option>
            <option>CNAME</option>
            <option>MX</option>
          </select>
          <input type="number" value={ttl} onChange={e=>setTtl(e.target.value)} style={{width:96, padding:10, borderRadius:8}} />
          <button onClick={resolveDNS} style={{padding:'10px 14px', borderRadius:8, background:'#06b6d4', border:'none'}}>{loading? 'Resolving...':'Resolve'}</button>
        </div>

        <div className="card" style={{marginTop:20}}>
          {result ? (
            result.error ? (
              <div>Error: {result.error}</div>
            ) : (
              <>
                <p><strong>Domain:</strong> {result.domain}</p>
                <p><strong>Type:</strong> {result.query_type}</p>
                <p><strong>IP/Record:</strong> {Array.isArray(result.ip) ? JSON.stringify(result.ip) : result.ip}</p>
                <p><strong>Cache Hit:</strong> {result.cache_hit ? 'Yes' : 'No'}</p>
                <p><strong>Time:</strong> {result.time}s</p>
                <h4 style={{marginTop:10}}>Resolution Steps</h4>
                <div className="steps">
                  <ol>
                    {result.steps.map((s,i)=><li key={i}>{s}</li>)}
                  </ol>
                </div>
              </>
            )
          ) : (
            <p>Enter a domain and click Resolve to simulate DNS resolution. TTL (seconds) controls cache lifetime in this demo.</p>
          )}
        </div>
      </div>
    </div>
  );
}
